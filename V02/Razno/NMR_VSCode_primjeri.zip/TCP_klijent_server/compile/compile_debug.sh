
gcc -Wall -Iinclude -g -c src/klijent_tcp.c \
-o obj/klijent_tcp_debug.o

gcc -Wall -Iinclude -g -c src/server_tcp.c \
-o obj/server_tcp_debug.o

gcc -Wall -Iinclude -g -c src/server_tcp_bez_provjera.c \
-o obj/server_tcp_bez_provjera_debug.o

gcc -fdiagnostics-color=always -fexceptions -fno-omit-frame-pointer -static-libasan \
obj/klijent_tcp_debug.o -o bin/klijent_tcp_debug

gcc -fdiagnostics-color=always -fexceptions -fno-omit-frame-pointer -static-libasan \
obj/server_tcp_debug.o -o bin/server_tcp_debug

gcc -fdiagnostics-color=always -fexceptions -fno-omit-frame-pointer -static-libasan \
obj/server_tcp_bez_provjera_debug.o -o bin/server_tcp_bez_provjera_debug 