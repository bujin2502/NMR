gcc -Wall -O2 -fexceptions -Iinclude -c src/klijent_tcp.c \
-o obj/klijent_tcp_release.o

gcc -Wall -O2 -fexceptions -Iinclude -c src/server_tcp.c \
-o obj/server_tcp_release.o

gcc -Wall -O2 -fexceptions -Iinclude -c src/server_tcp_bez_provjera.c \
-o obj/server_tcp_bez_provjera_release.o

gcc -fno-omit-frame-pointer -static-libsan obj/klijent_tcp_release.o \
-o bin/klijent_tcp_release

gcc -fno-omit-frame-pointer -static-libsan obj/server_tcp_release.o \
-o bin/server_tcp_release

gcc -fno-omit-frame-pointer -static-libsan obj/server_tcp_bez_provjera_release.o \
-o bin/server_tcp_bez_provjera_release